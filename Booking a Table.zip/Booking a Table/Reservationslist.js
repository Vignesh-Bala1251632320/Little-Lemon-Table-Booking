import React from 'react';
import axios from 'axios';

const ReservationsList = ({ reservations, fetchReservations }) => {
  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/reservations/${id}`);
      fetchReservations(); // Refresh the reservations list
    } catch (error) {
      console.error('There was an error deleting the reservation!', error);
    }
  };

  return (
    <div>
      <h2>Reservations</h2>
      <ul>
        {reservations.map((reservation) => (
          <li key={reservation.id}>
            {reservation.name} - {reservation.date} {reservation.time} for {reservation.numPeople} people
            <button onClick={() => handleDelete(reservation.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ReservationsList;
