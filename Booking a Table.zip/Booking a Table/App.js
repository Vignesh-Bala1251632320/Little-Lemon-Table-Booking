import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BookingForm from './BookingForm';
import ReservationsList from './ReservationsList';

const App = () => {
  const [reservations, setReservations] = useState([]);

  const fetchReservations = async () => {
    try {
      const response = await axios.get('/api/reservations');
      setReservations(response.data);
    } catch (error) {
      console.error('There was an error fetching the reservations!', error);
    }
  };

  useEffect(() => {
    fetchReservations();
  }, []);

  return (
    <div>
      <h1>Little Lemon Restaurant</h1>
      <BookingForm fetchReservations={fetchReservations} />
      <ReservationsList reservations={reservations} fetchReservations={fetchReservations} />
    </div>
  );
};

export default App;
