import React, { useState } from 'react';
import axios from 'axios';

const BookingForm = ({ fetchReservations }) => {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [numPeople, setNumPeople] = useState('');
  const [contactInfo, setContactInfo] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const reservation = { name, date, time, numPeople, contactInfo };
    try {
      await axios.post('/api/reservations', reservation);
      fetchReservations(); // Refresh the reservations list
    } catch (error) {
      console.error('There was an error making the reservation!', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Book a Table</h2>
      <label>
        Name:
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
      </label>
      <label>
        Date:
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
      </label>
      <label>
        Time:
        <input type="time" value={time} onChange={(e) => setTime(e.target.value)} required />
      </label>
      <label>
        Number of People:
        <input type="number" value={numPeople} onChange={(e) => setNumPeople(e.target.value)} required />
      </label>
      <label>
        Contact Info:
        <input type="text" value={contactInfo} onChange={(e) => setContactInfo(e.target.value)} />
      </label>
      <button type="submit">Submit</button>
    </form>
  );
};

export default BookingForm;
